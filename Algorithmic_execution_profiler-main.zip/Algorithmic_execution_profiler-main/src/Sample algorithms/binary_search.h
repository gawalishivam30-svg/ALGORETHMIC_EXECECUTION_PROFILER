class Main {
    function void main() {
        var int n, i, repeat, repeatLimit;
        var int foundResult, missingResult;
        var int foundCount, missingCount, valid;
        var Array port, data;

        let port = 24577;

        // Setup outside ROI
        let n = N_VALUE;
        let data = Array.new(n);

        // Initialize sorted array
        let i = 0;

        while (i < n) {
            let data[i] = i;
            let i = i + 1;
        }

        let repeat = 0;
        let repeatLimit = 1;

        let foundCount = 0;
        let missingCount = 0;

        // ROI START
        let port[0] = 1;

        while (repeat < repeatLimit) {

            // Successful binary search
            let foundResult = Main.binarySearch(
                data, n, n - 1
            );

            // Unsuccessful binary search
            let missingResult = Main.binarySearch(
                data, n, n
            );

            if (foundResult = (n - 1)) {
                let foundCount = foundCount + 1;
            }

            if (missingResult = (-1)) {
                let missingCount = missingCount + 1;
            }

            let repeat = repeat + 1;
        }

        // ROI END
        let port[1] = 1;

        // Correctness verification outside ROI
        let valid = 0;

        if (foundCount = repeatLimit) {
            if (missingCount = repeatLimit) {
                let valid = 1;
            }
        }

        do Memory.poke(16384, valid);

        return;
    }

    function int binarySearch(
        Array data,
        int n,
        int target
    ) {
        var int low, high, mid, answer;

        let low = 0;
        let high = n - 1;
        let answer = -1;

        while (low < (high + 1)) {

            let mid = (low + high) / 2;

            if (data[mid] = target) {

                let answer = mid;

                let low = high + 1;

            } else {

                if (data[mid] < target) {
                    let low = mid + 1;
                } else {
                    let high = mid - 1;
                }
            }
        }

        return answer;
    }
}
